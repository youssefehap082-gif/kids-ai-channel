def post_daily_update(topic, video_link):
    print(f"Creating Community Post: 'Did you watch our new video on {topic}?'")
    # Uses YouTube API 'insert' on captions/activities endpoints
